"""
This script compiles capacity and network results for individual MGA runs into two files for ease of processing.

"""

using CSV
using DataFrames
using YAML


# Folder Path - Input path to caserunner here
yml2dict(path::AbstractString) = YAML.load_file(path)
dict2yml(d::Dict, path::AbstractString) = YAML.write_file(path, d)

csv2dataframe(path::AbstractString) = CSV.read(path, header=1, DataFrame)
dataframe2csv(df::DataFrame, path::AbstractString) = CSV.write(path, df)

"""
Function to add case label column
"""

function label_col(df::DataFrame, MGA_Run::AbstractString)
    row_num = nrow(df)
    A = Vector{AbstractString}(undef, row_num)
    for i in 1:row_num
        A[i] = MGA_Run
    end
    df.MGA_Iteration = A
    return df
end

function make_label(case_num::Int64, direction::AbstractString, run_num::Int64)
    case = "Case_"
    c_num = string(case_num)
    r_num = string(run_num)
    label = case*c_num*"_"*direction*"_"*r_num
    return label
end

function parse_name(file_name::AbstractString)
    secs = split(file_name, "_")
    num = parse(Int64,secs[end])
    return num
end

function create_csvs(df::DataFrame,out_fold::AbstractString, file_name::AbstractString)
    path = joinpath(out_fold, file_name)
    dataframe2csv(df, path)
    return
end

function build_dfs(file_name::AbstractString, raw_net_df::DataFrame, raw_cap_df::DataFrame, raw_costs_df::DataFrame,raw_ems_df::DataFrame, max::Int64)
    capacity = "capacity.csv"
    network = "network_expansion.csv"
    costs = "costs.csv"
    emissions = "emissions.csv"
    folder = readdir(joinpath(pwd(),file_name), join = true, sort = true)
    fold_name = readdir(joinpath(pwd(),file_name), join = false, sort = true)
    count = 0
    for file in folder
        count += 1
        if fold_name[count] != "MGAdists.csv"
            case = readdir(file, join = true, sort = true)
            name = readdir(file, join = false, sort = true)
            counter = 0
            for f in case
                counter += 1
                if name[counter] == capacity
                    raw_cap_df = create_and_append(f,parse_name(fold_name[count]),raw_cap_df, max,0)
                elseif name[counter] == network
                    raw_net_df = create_and_append(f,parse_name(fold_name[count]),raw_net_df, max,0)
                elseif name[counter] == costs
                    raw_costs_df = create_and_append(f,parse_name(fold_name[count]),raw_costs_df, max,1)
                elseif name[counter] == emissions
                    raw_ems_df = create_and_append(f,parse_name(fold_name[count]),raw_ems_df, max,1)
                end
            end
        end
    end
    return raw_net_df, raw_cap_df, raw_costs_df,raw_ems_df
end

function compile_dfs()
    """
    mga_max = "MGAResults_max"
    mga_min = "MGAResults_min"
    
    mga_fold = "MGAResults"
    """
    mga_replicate = "MGAReplicate"
    raw_cap_df,raw_net_df,raw_costs_df, raw_ems_df = retrieve_opt()
    dfs = [raw_cap_df,raw_net_df,raw_costs_df, raw_ems_df]
    for i in eachindex(dfs)
        deleteat!(dfs[i], collect(1:nrow(dfs[i])))
    end
    
    
    raw_net_df, raw_cap_df,raw_costs_df,raw_ems_df = build_dfs(mga_replicate, raw_net_df, raw_cap_df,raw_costs_df,raw_ems_df, 2)
    #raw_net_df, raw_cap_df,raw_costs_df,raw_ems_df = build_dfs(mga_max, raw_net_df, raw_cap_df,raw_costs_df,raw_ems_df, 1)
    #raw_net_df, raw_cap_df,raw_costs_df,raw_ems_df = build_dfs(mga_min, raw_net_df, raw_cap_df,raw_costs_df,raw_ems_df, 0)
    return raw_net_df, raw_cap_df,raw_costs_df,raw_ems_df
end

function create_and_append(path::AbstractString, iter::Int64, old_df::DataFrame, max::Int64, row::Int64)
    new_df = csv2dataframe(path)
    if max == 0
        iter = iter*2
    elseif max == 1
        iter = 2*iter - 1
    elseif max == 2
        iter = iter
    end
    new_df = label_col(new_df, string(iter))
    if row == 0
        append!(old_df, new_df)
    else
        dfr = new_df[row,:]
        push!(old_df,dfr)
    end
    return old_df
end

function retrieve_opt()
    results = "Results"
    opt = "0"
    wd = pwd()
    cd(joinpath(wd,results))
    capacity = joinpath(joinpath(wd,results),"capacity.csv")
    network = joinpath(joinpath(wd,results), "network_expansion.csv")
    costs = joinpath(joinpath(wd,results), "costs.csv")
    ems = joinpath(joinpath(wd,results), "emissions.csv")
    dir = readdir(pwd(), join = true, sort = false)
    name = readdir(pwd(), join = false, sort = false)
    counter = 0
    fin_cost_df = DataFrame()
    fin_ems_df = DataFrame()
    for file in dir
        counter += 1
        println(name[counter])
        if file == capacity
            global cap_df = csv2dataframe(file)
            global cap_df = label_col(cap_df,opt)
        elseif file == network
            global net_df = csv2dataframe(file)
            global net_df = label_col(net_df,opt)
        elseif file == costs
            global cost_df = csv2dataframe(file)
            global cost_df = label_col(cost_df,opt)
            dfr = cost_df[1,:]
            push!(fin_cost_df,dfr)
        elseif file == ems
            global ems_df = csv2dataframe(file)
            global ems_df = label_col(ems_df,opt)
            dfr = ems_df[1,:]
            push!(fin_ems_df,dfr)
        end
    end
    cd(wd)
    return cap_df,net_df,fin_cost_df,fin_ems_df
end

function copyall(all_cases::AbstractString) # Pass in working directory of Simple caserunner
    a = readdir(all_cases, join=false)
    year = raw"2030"
    case_name = "p7_m_2030_deepdecarbonization_80ER_mid"
    results = "Results"
    inputs = "Inputs"
    output = "/tigress/ml6802/GenX/PJM_MGA/PJM_Results/2030_PJM_80CAP_MGA"
    for f in a
        input_path = joinpath(all_cases, f, year, case_name, inputs)
        file_name = "inputs"*string(f)
        output_path = joinpath(output, f)
        cp(input_path, output_path)
    end
end

function copy_dists()
    wd = pwd()
    mga_max = "MGAResults_max"
    mga_min = "MGAResults_min"
    mga_dists = "MGAdists.csv"
    Comp_Results = "Comp_MGA"
    cp(joinpath(wd,mga_max,mga_dists),joinpath(wd,Comp_Results,mga_dists))
    return
end

# Moving all results files into one consolidated file
function main()
    out_capacity = "Raw_Capacity.csv"
    out_network = "Raw_Network.csv"
    out_costs = "Raw_Costs.csv"
    out_ems = "Raw_Emissions.csv"
    present_dir = pwd()
    Comp_Results = "Comp_MGA"
    if isdir(joinpath(present_dir,Comp_Results)) == 0
        mkdir(Comp_Results)
    end
    Final_path = joinpath(pwd(),Comp_Results)

    raw_network_df, raw_cap_df, raw_costs_df, raw_ems_df = compile_dfs()
    create_csvs(raw_cap_df, Final_path, out_capacity)
    create_csvs(raw_network_df, Final_path, out_network)
    create_csvs(raw_costs_df, Final_path, out_costs)
    create_csvs(raw_ems_df, Final_path, out_ems)
    #copy_dists()
    return
end 

main()
# copyall("/tigress/ml6802/GenX/SimpleGenXCaseRunner_Local2/Cases")